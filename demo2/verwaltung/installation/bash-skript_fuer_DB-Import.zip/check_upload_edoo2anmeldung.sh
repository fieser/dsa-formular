#!/bin/bash

# Verzeichnis, das überprüft werden soll
dir="/var/www/html/verwaltung/daten"

# Hash-Werte der Dateien im Verzeichnis speichern
find "$dir" -type f -exec md5sum {} + > /tmp/current_md5_anmeldung

# Prüfen, ob es eine vorherige Hash-Werte-Datei gibt
if [ -f /tmp/previous_md5_anmeldung ]; then
    # Überprüfen, ob sich die Hash-Werte seit dem letzten Durchlauf geändert haben
    changes=$(diff /tmp/previous_md5_anmeldung /tmp/current_md5_anmeldung)
    if [ -n "$changes" ]; then
        # Ausführen des PHP-Skripts, wenn sich Dateien geändert haben
        /usr/bin/php /var/www/html/verwaltung/import_edoo.php &&
	/usr/bin/php /var/www/html/verwaltung/fehler_ermitteln.php
	/usr/bin/php /var/www/html/verwaltung/import_wl.php
    fi
fi

# Aktuelle Hash-Werte als die vorherigen speichern
mv /tmp/current_md5_anmeldung /tmp/previous_md5_anmeldung

